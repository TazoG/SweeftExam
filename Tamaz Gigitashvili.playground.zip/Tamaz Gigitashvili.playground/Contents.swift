import UIKit

// Task 1

func lengthOfLongestSubstring(_ s: String) -> Int {
    var charMap = [Character: Int]()
    var maxLength = 0
    var start = 0

    let chars = Array(s)

    for (i, char) in chars.enumerated() {
        if let lastIdx = charMap[char], lastIdx >= start {
            start = lastIdx + 1
        }

        charMap[char] = i

        maxLength = max(maxLength, i - start + 1)
    }

    return maxLength
}

print(lengthOfLongestSubstring("abcabcbb"))
print(lengthOfLongestSubstring("bbbbb"))

// Task 2

func minWindow(_ s: String, _ t: String) -> String {
    let sChars = Array(s), tChars = Array(t)
    var tDict = [Character: Int](), windowDict = [Character: Int]()
    var have = 0, need = tChars.count > 0 ? Set(tChars).count : 0
    var result = (start: 0, end: Int.max, length: Int.max)

    tChars.forEach { tDict[$0, default: 0] += 1 }

    var left = 0
    for right in 0..<sChars.count {
        let rChar = sChars[right]
        windowDict[rChar, default: 0] += 1

        if let windowCount = windowDict[rChar], let tCount = tDict[rChar], windowCount == tCount {
            have += 1
        }

        while have == need {
            if (right - left) < result.length {
                result = (start: left, end: right, length: (right - left))
            }

            let lChar = sChars[left]
            windowDict[lChar, default: 0] -= 1
            if let windowCount = windowDict[lChar], let tCount = tDict[lChar], windowCount < tCount {
                have -= 1
            }
            left += 1
        }
    }

    return result.length < Int.max ? String(sChars[result.start...result.end]) : ""
}

print(minWindow("ADOBECODEBANC", "ABC"))
print(minWindow("a", "aa"))

// Task 3

func wordBreak(_ s: String, _ words: [String]) -> Bool {
    var dp = [Bool](repeating: false, count: s.count + 1)
    dp[0] = true

    let wordsSet = Set(words)
    let sChars = Array(s)

    for i in 1...sChars.count {
        for j in 0..<i {
            if dp[j] && wordsSet.contains(String(sChars[j..<i])) {
                dp[i] = true
                break
            }
        }
    }

    return dp[s.count]
}


print(wordBreak("leetcode", ["leet", "code"]))
print(wordBreak("applepenapple", ["apple", "pen"]))

// Task 4

func topKFrequent(_ nums: [Int], _ k: Int) -> [Int] {
    var frequencyDict = [Int: Int]()
    for num in nums {
        frequencyDict[num, default: 0] += 1
    }

    let frequencyPairs = frequencyDict.map { $0 }

    let topKFrequent = frequencyPairs.sorted(by: { $0.value > $1.value }).prefix(k).map { $0.key }

    return topKFrequent
}

print(topKFrequent([1,1,1,2,2,3], 2))
print(topKFrequent([1], 1))

// Task 5

func minMeetingRooms(_ intervals: [[Int]]) -> Int {
    let startTimes = intervals.map { $0[0] }.sorted()
    let endTimes = intervals.map { $0[1] }.sorted()

    var startPointer = 0
    var endPointer = 0
    var rooms = 0

    while startPointer < startTimes.count {
        if startTimes[startPointer] >= endTimes[endPointer] {
            endPointer += 1
        } else {
            rooms += 1
        }
        startPointer += 1
    }

    return rooms
}

print(minMeetingRooms([[0, 30],[5, 10],[15, 20]]))
print(minMeetingRooms([[7,10],[2,4]]))



